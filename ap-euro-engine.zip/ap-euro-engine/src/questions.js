export const questionBank = [
  {
    id: "euro-era1-001",
    era: 1,
    eraLabel: "1450–1648",
    unit: "Renaissance & Reformation",
    isms: ["Humanism", "Protestantism"],
    stimulus: {
      type: "text",
      source: "Martin Luther, Ninety-Five Theses, 1517 (Thesis 86)",
      content:
        "Why does the pope, whose wealth today is greater than the wealth of the richest Crassus, build the basilica of Saint Peter with the money of poor believers rather than with his own money?",
      authorContext: {
        socialClass: "Lower clergy / academic monk",
        politicalAffiliation:
          "Initially loyal to the Church; later leader of the Protestant Reformation",
        bias:
          "Luther was deeply frustrated with Church corruption and the sale of indulgences. His academic background made him frame grievances in theological and rational terms rather than purely emotional ones.",
      },
    },
    questions: [
      {
        question:
          "Luther's argument in the Ninety-Five Theses most directly challenged which aspect of the Catholic Church?",
        options: [
          "A. The Church's interpretation of Scripture as the sole source of Christian truth",
          "B. The Church's use of wealth and financial practices like the sale of indulgences",
          "C. The political authority of the Holy Roman Emperor over religious affairs",
          "D. The validity of the sacraments administered by corrupt clergy",
        ],
        answer: "B",
        explanation:
          "Luther directly attacks the Pope's wealth and his use of poor believers' money for the Basilica — the central grievance being financial corruption and indulgence sales, not scripture interpretation (that came later).",
        distractors: {
          A: "Scripture as the sole authority ('sola scriptura') is a later Lutheran doctrine — this specific thesis is about money and corruption, not biblical authority.",
          C: "The Holy Roman Emperor's authority is not mentioned. Luther is critiquing the Pope's financial decisions, not the political structure of the Empire.",
          D: "Sacramental validity was debated later in the Reformation. Thesis 86 is narrowly focused on the economic hypocrisy of indulgence sales.",
        },
      },
      {
        question:
          "Which of the following groups would most likely have used Luther's argument to advance their own political goals?",
        options: [
          "A. Spanish Inquisitors seeking to root out heresy",
          "B. German princes who resented Church taxation and papal interference",
          "C. Merchants who profited from the sale of indulgences",
          "D. Jesuits committed to the Counter-Reformation",
        ],
        answer: "B",
        explanation:
          "German princes had strong political and economic incentives to break from Rome — they could seize Church lands and end papal financial extractions. Luther's critique gave them theological cover for what was also a power grab.",
        distractors: {
          A: "The Inquisition actively suppressed reformers like Luther — they would have viewed his theses as dangerous heresy, not a useful argument.",
          C: "Merchants who sold indulgences profited from the very system Luther attacked. They had every reason to oppose him.",
          D: "The Jesuits were founded specifically to combat Protestant ideas — they would have defended papal authority, not exploited Luther's critique.",
        },
      },
    ],
  },
  {
    id: "euro-era2-001",
    era: 2,
    eraLabel: "1648–1815",
    unit: "Absolutism & Enlightenment",
    isms: ["Absolutism", "Mercantilism"],
    stimulus: {
      type: "text",
      source: "Jean-Baptiste Colbert, Memorandum to Louis XIV on Finances, 1670",
      content:
        "Commerce is a perpetual and peaceable war of wit and energy among all nations. Each nation works incessantly to have its fair share of commerce with other countries, and to gain an advantage over them... The greatness and strength of Your Majesty are solely dependent upon his finances.",
      authorContext: {
        socialClass:
          "Royal minister / bureaucratic elite (bourgeois origin, not noble by birth)",
        politicalAffiliation:
          "Chief minister of finance under Louis XIV; architect of French Mercantilism",
        bias:
          "Colbert's entire career was built on maximizing royal revenue. He viewed trade as a zero-sum competition and believed state control of the economy was essential for French dominance. His perspective reflects a minister trying to justify his own policies to his king.",
      },
    },
    questions: [
      {
        question:
          "Colbert's description of commerce as a 'perpetual and peaceable war' most directly reflects which economic ideology?",
        options: [
          "A. Laissez-faire capitalism, as advocated by Adam Smith",
          "B. Mercantilism, emphasizing state-controlled trade and accumulation of wealth",
          "C. Physiocracy, which held that land was the source of all wealth",
          "D. Marxist theory that commerce exploits the laboring classes",
        ],
        answer: "B",
        explanation:
          "Colbert is the defining figure of Mercantilism — the belief that trade is a competition nations must win through state regulation, favorable balances of trade, and colonial extraction. His framing of commerce as 'war' captures the zero-sum mercantilist worldview perfectly.",
        distractors: {
          A: "Adam Smith's Wealth of Nations (1776) argued against state interference in commerce — the opposite of Colbert's position. Laissez-faire means 'let it be,' not state-directed trade wars.",
          C: "Physiocracy argued that agriculture, not trade, created wealth. Colbert is focused entirely on commerce and finance, which Physiocrats actually criticized.",
          D: "Marxist theory emerged in the 1840s, nearly 200 years after this document. Colbert has no interest in class exploitation — his concern is royal power and national revenue.",
        },
      },
    ],
  },
  {
    id: "euro-era2-002",
    era: 2,
    eraLabel: "1648–1815",
    unit: "French Revolution",
    isms: ["Republicanism", "Radicalism", "Nationalism"],
    stimulus: {
      type: "image",
      url: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/Jacques-Louis_David_-_Marat_assassinated_-_Google_Art_Project.jpg/800px-Jacques-Louis_David_-_Marat_assassinated_-_Google_Art_Project.jpg",
      caption:
        "Jacques-Louis David, The Death of Marat, 1793. Oil on canvas. Depicted moments after Marat was stabbed in his medicinal bath by Charlotte Corday.",
      authorContext: {
        socialClass: "Elite court painter turned revolutionary propagandist",
        politicalAffiliation:
          "Jacobin and close ally of Robespierre; used art as political propaganda",
        bias:
          "David was deeply invested in the Revolution's radical phase. He deliberately painted Marat in a Christ-like pose to martyr him and rally public support for the Jacobins against moderate Girondins.",
      },
    },
    questions: [
      {
        question:
          "David's painting of Marat's death was most likely intended to serve which purpose?",
        options: [
          "A. Document historical events accurately for future generations",
          "B. Critique the violence of the radical phase of the French Revolution",
          "C. Glorify Marat as a martyr and generate support for the Jacobin faction",
          "D. Demonstrate Neoclassical techniques to students at the Royal Academy",
        ],
        answer: "C",
        explanation:
          "David was a committed Jacobin who used art as propaganda. The Christ-like pose, the serene expression, and the deliberate omission of Marat's severe skin condition all serve to heroize and martyr him, rallying support for the radical Jacobin government during the Terror.",
        distractors: {
          A: "David intentionally idealized the scene — Marat's disfiguring skin disease is invisible, and his expression is peaceful rather than agonized. This is propaganda, not historical documentation.",
          B: "David fully supported the Jacobin Terror. He was not critiquing revolutionary violence; he was celebrating its victims as heroes.",
          D: "The Royal Academy was associated with the ancien régime. By 1793, David was using his art entirely for revolutionary political purposes, not academic demonstrations.",
        },
      },
    ],
  },
  {
    id: "euro-era3-001",
    era: 3,
    eraLabel: "1815–1914",
    unit: "Nationalism & Unification",
    isms: ["Nationalism", "Conservatism", "Realpolitik"],
    stimulus: {
      type: "text",
      source:
        "Otto von Bismarck, Speech to the Prussian Budget Committee, September 30, 1862",
      content:
        "The position of Prussia in Germany will not be determined by its liberalism but by its power... Prussia must concentrate its strength and hold it for the favorable moment, which has already come and gone several times. Since the treaties of Vienna, our frontiers have been ill-designed for a healthy body politic. Not through speeches and majority decisions will the great questions of the day be decided — that was the great mistake of 1848 and 1849 — but by iron and blood.",
      authorContext: {
        socialClass: "Junker (Prussian landed aristocracy)",
        politicalAffiliation:
          "Conservative monarchist; Minister-President of Prussia; architect of German unification from above",
        bias:
          "Bismarck was a pragmatic conservative who despised liberal nationalism. He deliberately used nationalist sentiment as a tool to expand Prussian power while suppressing genuine democratic movements. His 'iron and blood' is a rejection of the liberal 1848 revolutions.",
      },
    },
    questions: [
      {
        question:
          "Bismarck's 'iron and blood' speech most directly repudiated the methods of which earlier European movement?",
        options: [
          "A. The Congress of Vienna (1815), which sought to restore conservative monarchies",
          "B. The Revolutions of 1848, which attempted to achieve national unification through liberal parliaments",
          "C. The French Revolution's Declaration of the Rights of Man",
          "D. The Chartist Movement in Britain, which demanded working-class voting rights",
        ],
        answer: "B",
        explanation:
          "Bismarck explicitly names 1848 and 1849 as the 'great mistake' — when German liberals tried to unify Germany through the Frankfurt Parliament using 'speeches and majority decisions.' He is arguing that real power, not democratic deliberation, will unify Germany.",
        distractors: {
          A: "The Congress of Vienna was a conservative settlement Bismarck actually admired. He criticizes its borders ('ill-designed frontiers') but not its method — he's attacking liberalism, not conservatism.",
          C: "The Declaration of the Rights of Man is French and from 1789. Bismarck's speech is specifically about German unification debates — the 1848 Frankfurt Parliament is the clear target.",
          D: "British Chartism is a working-class British movement with no direct connection to German unification. Bismarck is not commenting on labor rights.",
        },
      },
      {
        question:
          "Bismarck's approach to German unification is best characterized as an example of which concept?",
        options: [
          "A. Liberal Nationalism — unification driven by popular sovereignty and constitutional government",
          "B. Realpolitik — pragmatic use of military power and diplomacy regardless of ideological principles",
          "C. Social Darwinism — belief that racial superiority justified German expansion",
          "D. Romanticism — appeal to shared cultural heritage and folk traditions to inspire unity",
        ],
        answer: "B",
        explanation:
          "Realpolitik is Bismarck's defining approach — cold, pragmatic, power-driven politics that ignores idealism. He used wars against Denmark, Austria, and France as calculated tools to unify Germany under Prussian dominance, not because of ideology but because of strategic interest.",
        distractors: {
          A: "Liberal Nationalism is exactly what Bismarck is rejecting. He dismisses 'speeches and majority decisions' — the tools of liberal nationalists at Frankfurt in 1848.",
          C: "Social Darwinism and racial ideology are associated with later figures. Bismarck's conservatism was about state power, not racial theory.",
          D: "Romanticism inspired cultural nationalism (Herder, Grimm brothers) but Bismarck was famously unsentimental. He used nationalism as a political tool, not a Romantic ideal.",
        },
      },
    ],
  },
  {
    id: "euro-era4-001",
    era: 4,
    eraLabel: "1914–Present",
    unit: "World Wars & Totalitarianism",
    isms: ["Totalitarianism", "Fascism", "Nationalism"],
    stimulus: {
      type: "text",
      source: "Benito Mussolini, The Doctrine of Fascism, 1932",
      content:
        "The foundation of Fascism is the conception of the State... For the Fascist, everything is in the State, and nothing human or spiritual exists, much less has value, outside the State. In this sense Fascism is totalitarian, and the Fascist State... interprets, develops, and potentiates the whole life of a people... The Fascist negation of socialism, democracy, liberalism should not be interpreted as a wish to push the world backwards.",
      authorContext: {
        socialClass:
          "Former socialist journalist turned authoritarian leader (Il Duce)",
        politicalAffiliation:
          "Founder of Italian Fascism; Prime Minister and dictator of Italy 1922–1943",
        bias:
          "Mussolini was consciously constructing an ideology to compete with both liberalism and Marxism. By 1932 he was already in power and writing this as a theoretical justification for his regime — it is explicitly self-serving political philosophy, not neutral analysis.",
      },
    },
    questions: [
      {
        question:
          "Mussolini's claim that 'everything is in the State' most directly contradicts which Enlightenment political tradition?",
        options: [
          "A. Absolutism, which also concentrated power in a central authority",
          "B. Liberalism, which emphasized individual rights existing prior to and above the state",
          "C. Conservatism, which valued tradition and organic social institutions",
          "D. Mercantilism, which emphasized state control of the economy",
        ],
        answer: "B",
        explanation:
          "Liberalism (Locke, Mill) holds that individuals possess natural rights that governments cannot violate — the individual exists before and above the state. Mussolini explicitly inverts this: the state is supreme, and nothing exists 'outside the State.' He even lists 'liberalism' as something Fascism negates.",
        distractors: {
          A: "Absolutism concentrated power in a monarch, not in an abstract 'State' as a living organism. Absolutism still had limits (divine law, natural law) that Mussolini's totalitarianism rejects entirely.",
          C: "Conservatism (Burke) actually valued independent institutions — church, family, local tradition — as buffers against state power. Mussolini's total state absorbs all of these.",
          D: "Mercantilism is an economic policy, not a political philosophy about individual rights. It doesn't address the relationship between the individual and the state.",
        },
      },
    ],
  },
];
