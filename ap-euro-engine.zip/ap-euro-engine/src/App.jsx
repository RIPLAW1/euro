import { useState, useEffect, useRef } from "react";
import { questionBank } from "./questions.js";

const TIMER_SECONDS = 75;
const ERA_COLORS = {
  1: { accent: "#d97706", bg: "rgba(120,53,15,0.15)", label: "Renaissance & Reformation" },
  2: { accent: "#7c3aed", bg: "rgba(76,29,149,0.15)", label: "Absolutism & Enlightenment" },
  3: { accent: "#0891b2", bg: "rgba(14,116,144,0.15)", label: "Industrialization & Nationalism" },
  4: { accent: "#dc2626", bg: "rgba(127,29,29,0.15)", label: "World Wars & Cold War" },
};

function IsmTag({ label }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center",
      background: "#1e1b4b", border: "1px solid #4338ca",
      color: "#a5b4fc", borderRadius: 20, padding: "2px 10px",
      fontSize: 11.5, fontWeight: 600, letterSpacing: 0.4,
      fontFamily: "monospace", whiteSpace: "nowrap",
    }}>
      #{label}
    </span>
  );
}

function TimerArc({ seconds, total, accent }) {
  const pct = seconds / total;
  const r = 22, circ = 2 * Math.PI * r;
  const color = seconds > 30 ? accent : seconds > 15 ? "#f59e0b" : "#ef4444";
  return (
    <div style={{ position: "relative", width: 60, height: 60, flexShrink: 0 }}>
      <svg width="60" height="60" style={{ transform: "rotate(-90deg)", position: "absolute" }}>
        <circle cx="30" cy="30" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="4" />
        <circle cx="30" cy="30" r={r} fill="none" stroke={color} strokeWidth="4"
          strokeDasharray={circ} strokeDashoffset={circ * (1 - pct)}
          style={{ transition: "stroke-dashoffset 1s linear, stroke 0.4s" }}
          strokeLinecap="round" />
      </svg>
      <div style={{
        position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "monospace", fontSize: 13, fontWeight: 700, color,
      }}>{seconds}</div>
    </div>
  );
}

function SourceTooltip({ context, dark }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    function handleClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <div ref={ref} style={{ position: "relative", display: "inline-block" }}>
      <button onClick={() => setOpen(o => !o)} style={{
        background: open ? "#7c3aed" : "transparent",
        border: "1.5px solid #7c3aed", borderRadius: 8,
        color: open ? "#fff" : "#a78bfa", padding: "5px 12px",
        cursor: "pointer", fontSize: 12.5, fontWeight: 700, fontFamily: "inherit",
        transition: "all 0.18s",
      }}>🔍 Source POV</button>
      {open && (
        <div style={{
          position: "absolute", top: "calc(100% + 8px)", left: 0, zIndex: 200,
          width: 320, background: dark ? "#1e1b4b" : "#f5f3ff",
          border: "1.5px solid #7c3aed", borderRadius: 12, padding: "16px 18px",
          boxShadow: "0 20px 40px rgba(0,0,0,0.5)",
          animation: "fadeSlideIn 0.22s ease",
        }}>
          <div style={{ fontWeight: 700, fontSize: 11, color: "#a78bfa", marginBottom: 12, letterSpacing: 1.2, textTransform: "uppercase" }}>
            Author Context
          </div>
          {[
            ["🏛 Social Class", context.socialClass],
            ["⚑ Political Affiliation", context.politicalAffiliation],
            ["⚠ Bias / Limitation", context.bias],
          ].map(([label, val]) => (
            <div key={label} style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 11.5, fontWeight: 700, color: "#7c3aed", marginBottom: 3 }}>{label}</div>
              <div style={{ fontSize: 13, color: dark ? "#c4b5fd" : "#374151", lineHeight: 1.55 }}>{val}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ImageStimulus({ stimulus }) {
  const [zoomed, setZoomed] = useState(false);
  return (
    <div>
      <div
        onClick={() => setZoomed(true)}
        style={{ position: "relative", cursor: "zoom-in", borderRadius: 10, overflow: "hidden", border: "1px solid #334155" }}
      >
        <img src={stimulus.url} alt={stimulus.caption}
          style={{ width: "100%", display: "block", maxHeight: 340, objectFit: "cover" }} />
        <div style={{
          position: "absolute", bottom: 8, right: 8, background: "rgba(0,0,0,0.7)",
          color: "#fff", borderRadius: 6, padding: "3px 8px", fontSize: 11, fontWeight: 600,
        }}>⊕ Click to zoom</div>
      </div>
      <p style={{ fontSize: 12.5, color: "#94a3b8", fontStyle: "italic", marginTop: 10, lineHeight: 1.55 }}>
        {stimulus.caption}
      </p>
      {zoomed && (
        <div
          onClick={() => setZoomed(false)}
          style={{
            position: "fixed", inset: 0, background: "rgba(0,0,0,0.92)", zIndex: 999,
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "zoom-out", animation: "fadeSlideIn 0.2s ease",
          }}
        >
          <img src={stimulus.url} alt={stimulus.caption}
            style={{ maxWidth: "90vw", maxHeight: "90vh", borderRadius: 8 }} />
          <div style={{ position: "absolute", top: 20, right: 24, color: "#fff", fontSize: 28, cursor: "pointer" }}>✕</div>
        </div>
      )}
    </div>
  );
}

function ResultsDashboard({ answers, total, onRestart, dark }) {
  const correct = answers.filter(a => a.correct).length;
  const pct = Math.round((correct / total) * 100);
  const grade = pct >= 80 ? "5" : pct >= 65 ? "4" : pct >= 50 ? "3" : "2";
  const gc = pct >= 80 ? "#34d399" : pct >= 65 ? "#60a5fa" : pct >= 50 ? "#fbbf24" : "#f87171";

  const ismMap = {};
  answers.forEach(a => {
    (a.isms || []).forEach(ism => {
      if (!ismMap[ism]) ismMap[ism] = { correct: 0, total: 0 };
      ismMap[ism].total++;
      if (a.correct) ismMap[ism].correct++;
    });
  });

  const bg = dark ? "#0a0f1e" : "#f8fafc";
  const card = dark ? "#111827" : "#fff";
  const border = dark ? "#1f2937" : "#e5e7eb";
  const text = dark ? "#e2e8f0" : "#1e293b";
  const muted = dark ? "#6b7280" : "#9ca3af";

  return (
    <div style={{ minHeight: "100vh", background: bg, padding: "48px 24px", display: "flex", justifyContent: "center", fontFamily: "'Playfair Display', Georgia, serif" }}>
      <div style={{ maxWidth: 700, width: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ fontSize: 72, fontWeight: 900, color: gc, lineHeight: 1 }}>{pct}%</div>
          <div style={{ fontSize: 16, color: muted, marginTop: 8 }}>
            {correct}/{total} correct · Projected AP Score: <strong style={{ color: gc }}>{grade}</strong>
          </div>
          <div style={{ fontSize: 14, color: muted, marginTop: 4 }}>
            {pct >= 80 ? "🏆 Excellent — exam ready!" : pct >= 65 ? "📖 Review missed questions below." : "💪 Keep grinding!"}
          </div>
        </div>

        {Object.keys(ismMap).length > 0 && (
          <div style={{ background: card, border: `1px solid ${border}`, borderRadius: 16, padding: "20px 24px", marginBottom: 28 }}>
            <div style={{ fontWeight: 700, fontSize: 12, color: "#818cf8", letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 16 }}>
              Ideology Performance
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
              {Object.entries(ismMap).map(([ism, data]) => {
                const p = Math.round((data.correct / data.total) * 100);
                const c = p === 100 ? "#34d399" : p >= 50 ? "#fbbf24" : "#f87171";
                return (
                  <div key={ism} style={{ background: dark ? "#1f2937" : "#f9fafb", border: `1.5px solid ${c}44`, borderRadius: 10, padding: "10px 16px" }}>
                    <div style={{ fontSize: 11, color: "#a5b4fc", fontFamily: "monospace", marginBottom: 4 }}>#{ism}</div>
                    <div style={{ fontSize: 20, fontWeight: 800, color: c }}>{p}%</div>
                    <div style={{ fontSize: 11, color: muted }}>{data.correct}/{data.total}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {answers.map((a, i) => (
            <div key={i} style={{
              background: card, border: `1.5px solid ${a.correct ? "#065f46" : "#7f1d1d"}`,
              borderRadius: 13, padding: "16px 20px",
            }}>
              <div style={{ display: "flex", gap: 10 }}>
                <span style={{ fontSize: 18, flexShrink: 0 }}>{a.correct ? "✅" : "❌"}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: text, marginBottom: 6, lineHeight: 1.5 }}>{a.question}</div>
                  {!a.correct && (
                    <div style={{ fontSize: 13, color: "#f87171", marginBottom: 6 }}>
                      Your answer: <strong>{a.chosen?.charAt(0)}</strong> · Correct: <strong style={{ color: "#34d399" }}>{a.correctAnswer?.charAt(0)}</strong>
                    </div>
                  )}
                  <div style={{ fontSize: 13.5, color: muted, lineHeight: 1.6 }}>{a.explanation}</div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
                    {(a.isms || []).map(ism => <IsmTag key={ism} label={ism} />)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ textAlign: "center", marginTop: 40 }}>
          <button onClick={onRestart} style={{
            background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
            color: "#fff", border: "none", borderRadius: 12,
            padding: "14px 40px", fontSize: 16, fontWeight: 700,
            cursor: "pointer", fontFamily: "inherit",
            boxShadow: "0 8px 24px rgba(124,58,237,0.4)",
          }}>↻ Practice Again</button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const allQuestions = [];
  questionBank.forEach(set => {
    set.questions.forEach((q) => {
      allQuestions.push({ set, q });
    });
  });

  const [dark, setDark] = useState(true);
  const [idx, setIdx] = useState(0);
  const [chosen, setChosen] = useState(null);
  const [timer, setTimer] = useState(TIMER_SECONDS);
  const [timesUp, setTimesUp] = useState(false);
  const [answers, setAnswers] = useState([]);
  const [finished, setFinished] = useState(false);
  const [showStudyMode, setShowStudyMode] = useState(false);
  const intervalRef = useRef(null);

  const { set, q } = allQuestions[idx];
  const eraColor = ERA_COLORS[set.era];

  useEffect(() => {
    setTimer(TIMER_SECONDS);
    setTimesUp(false);
    setShowStudyMode(false);
  }, [idx]);

  useEffect(() => {
    if (chosen || timesUp) return;
    clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setTimer(t => {
        if (t <= 1) { clearInterval(intervalRef.current); setTimesUp(true); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(intervalRef.current);
  }, [chosen, timesUp, idx]);

  const handleAnswer = (opt) => {
    if (chosen || timesUp) return;
    clearInterval(intervalRef.current);
    setChosen(opt);
    setAnswers(prev => [...prev, {
      question: q.question,
      correct: opt.charAt(0) === q.answer,
      chosen: opt,
      correctAnswer: q.options.find(o => o.startsWith(q.answer)),
      explanation: q.explanation,
      isms: set.isms,
    }]);
  };

  const handleNext = () => {
    if (idx + 1 >= allQuestions.length) { setFinished(true); return; }
    setIdx(i => i + 1);
    setChosen(null);
  };

  const handleRestart = () => {
    setIdx(0); setChosen(null); setAnswers([]);
    setFinished(false); setTimesUp(false); setShowStudyMode(false);
  };

  if (finished) {
    return <ResultsDashboard answers={answers} total={allQuestions.length} onRestart={handleRestart} dark={dark} />;
  }

  const bg = dark ? "#0a0f1e" : "#f1f5f9";
  const panelBg = dark ? "#0c1220" : "#fafafa";
  const border = dark ? "#1f2937" : "#e5e7eb";
  const text = dark ? "#e2e8f0" : "#1e293b";
  const muted = dark ? "#6b7280" : "#9ca3af";
  const card = dark ? "#111827" : "#ffffff";

  const optStyle = (opt) => {
    const letter = opt.charAt(0);
    const answered = chosen || timesUp;
    if (!answered) return { bg: card, border: border, color: text };
    if (letter === q.answer) return { bg: "#064e3b", border: "#059669", color: "#6ee7b7" };
    if (opt === chosen) return { bg: "#450a0a", border: "#dc2626", color: "#fca5a5" };
    return { bg: dark ? "#0a0f1e" : "#f8fafc", border: dark ? "#111827" : "#e5e7eb", color: dark ? "#374151" : "#cbd5e1" };
  };

  return (
    <div style={{ minHeight: "100vh", background: bg, color: text, fontFamily: "'Playfair Display', Georgia, serif", display: "flex", flexDirection: "column" }}>

      {/* Header */}
      <header style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "12px 28px", borderBottom: `1px solid ${border}`,
        background: dark ? "#0a0f1e" : "#fff", position: "sticky", top: 0, zIndex: 100,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: `linear-gradient(135deg, ${eraColor.accent}, #7c3aed)`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 17, fontWeight: 900, color: "#fff", fontStyle: "italic",
          }}>E</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>AP Euro Stimulus Engine</div>
            <div style={{ fontSize: 11, color: muted, letterSpacing: 1.2, textTransform: "uppercase", fontFamily: "monospace" }}>
              Era {set.era}: {set.eraLabel} · Q{idx + 1}/{allQuestions.length}
            </div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
            {set.isms.map(ism => <IsmTag key={ism} label={ism} />)}
          </div>
          <TimerArc seconds={timer} total={TIMER_SECONDS} accent={eraColor.accent} />
          <button onClick={() => setDark(d => !d)} style={{
            background: dark ? "#1f2937" : "#f1f5f9", border: `1px solid ${border}`,
            borderRadius: 8, padding: "6px 12px", cursor: "pointer", color: text,
            fontSize: 12.5, fontFamily: "inherit",
          }}>{dark ? "☀️ Light" : "🌙 Dark"}</button>
        </div>
      </header>

      {/* Progress bar */}
      <div style={{ height: 3, background: dark ? "#1f2937" : "#e5e7eb" }}>
        <div style={{
          height: "100%", width: `${(idx / allQuestions.length) * 100}%`,
          background: `linear-gradient(90deg, ${eraColor.accent}, #7c3aed)`,
          transition: "width 0.5s ease",
        }} />
      </div>

      {/* Era banner */}
      <div style={{
        padding: "6px 28px", fontSize: 11.5,
        background: eraColor.bg, borderBottom: `1px solid ${eraColor.accent}33`,
        color: eraColor.accent, fontFamily: "monospace", fontWeight: 600, letterSpacing: 0.8,
      }}>
        Era {set.era} · {set.unit}
      </div>

      {/* Two-pane layout */}
      <div style={{ display: "flex", flex: 1, overflow: "hidden", minHeight: "calc(100vh - 104px)" }}>

        {/* LEFT: Stimulus */}
        <div style={{
          width: "44%", minWidth: 280, borderRight: `1px solid ${border}`,
          overflowY: "auto", padding: "28px 26px", background: panelBg,
        }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
            <span style={{
              fontSize: 10.5, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700,
              color: eraColor.accent, background: eraColor.bg, padding: "3px 10px", borderRadius: 6,
              fontFamily: "monospace",
            }}>
              {set.stimulus.type === "image" ? "Visual Stimulus" : "Primary Source"}
            </span>
            <SourceTooltip context={set.stimulus.authorContext} dark={dark} />
          </div>

          {set.stimulus.type === "image" ? (
            <ImageStimulus stimulus={set.stimulus} />
          ) : (
            <>
              <div style={{ fontSize: 12.5, color: muted, fontStyle: "italic", marginBottom: 14, lineHeight: 1.5 }}>
                {set.stimulus.source}
              </div>
              <blockquote style={{
                borderLeft: `3px solid ${eraColor.accent}`,
                paddingLeft: 20, fontSize: 16.5, lineHeight: 1.9,
                color: text, fontStyle: "italic",
              }}>
                "{set.stimulus.content}"
              </blockquote>
            </>
          )}
        </div>

        {/* RIGHT: Questions */}
        <div style={{ flex: 1, overflowY: "auto", padding: "28px 34px" }}>
          {timesUp && !chosen && (
            <div style={{
              background: "#450a0a", border: "1.5px solid #dc2626", borderRadius: 10,
              padding: "10px 16px", marginBottom: 20, fontSize: 14, color: "#fca5a5", fontWeight: 600,
              animation: "fadeSlideIn 0.3s ease",
            }}>⏰ Time's up! Correct answer highlighted below.</div>
          )}

          <div style={{ fontSize: 11, letterSpacing: 1.5, textTransform: "uppercase", color: muted, marginBottom: 10, fontWeight: 600, fontFamily: "monospace" }}>
            Question {idx + 1} of {allQuestions.length}
          </div>

          <div style={{ fontSize: 19.5, lineHeight: 1.75, color: text, fontWeight: 700, marginBottom: 26 }}>
            {q.question}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {q.options.map((opt, i) => {
              const s = optStyle(opt);
              return (
                <button key={i}
                  onClick={() => handleAnswer(opt)}
                  disabled={!!chosen || timesUp}
                  style={{
                    background: s.bg, border: `1.5px solid ${s.border}`, borderRadius: 12,
                    padding: "13px 17px", textAlign: "left",
                    cursor: chosen || timesUp ? "default" : "pointer",
                    color: s.color, fontSize: 15.5, lineHeight: 1.5,
                    fontFamily: "inherit", display: "flex", gap: 12, alignItems: "flex-start",
                    transition: "transform 0.14s, opacity 0.14s",
                  }}
                  onMouseEnter={e => { if (!chosen && !timesUp) e.currentTarget.style.transform = "translateX(3px)"; }}
                  onMouseLeave={e => { e.currentTarget.style.transform = "translateX(0)"; }}
                >
                  <span style={{
                    width: 28, height: 28, borderRadius: 7, flexShrink: 0,
                    background: s.border + "33", display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 12, fontWeight: 700, color: s.color, fontFamily: "monospace", marginTop: 1,
                  }}>{opt.charAt(0)}</span>
                  <span>{opt.slice(3)}</span>
                </button>
              );
            })}
          </div>

          {/* Feedback panel */}
          {(chosen || timesUp) && (
            <div style={{ marginTop: 26, animation: "fadeSlideIn 0.4s ease" }}>
              <div style={{
                background: chosen?.charAt(0) === q.answer ? (dark ? "#064e3b" : "#ecfdf5") : (dark ? "#450a0a" : "#fef2f2"),
                border: `1.5px solid ${chosen?.charAt(0) === q.answer ? "#059669" : "#dc2626"}`,
                borderRadius: 13, padding: "16px 20px", marginBottom: 14,
              }}>
                <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 6, color: chosen?.charAt(0) === q.answer ? "#34d399" : "#f87171" }}>
                  {timesUp && !chosen ? "⏰ Time Expired" : chosen?.charAt(0) === q.answer ? "✅ Correct!" : "❌ Incorrect"}
                </div>
                <div style={{ fontSize: 14.5, lineHeight: 1.7, color: dark ? "#cbd5e1" : "#374151" }}>
                  <strong>Why this is right:</strong> {q.explanation}
                </div>
              </div>

              {q.distractors && (
                <div style={{
                  background: card, border: `1px solid ${border}`,
                  borderRadius: 13, padding: "16px 20px", marginBottom: 14,
                }}>
                  <div style={{ fontWeight: 700, fontSize: 12, color: "#f59e0b", marginBottom: 12, fontFamily: "monospace", letterSpacing: 0.5 }}>
                    🚨 Why the wrong answers are wrong
                  </div>
                  {Object.entries(q.distractors).map(([letter, reason]) => (
                    <div key={letter} style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: 10 }}>
                      <span style={{
                        width: 22, height: 22, borderRadius: 5, background: "#7f1d1d",
                        color: "#fca5a5", display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 11, fontWeight: 700, flexShrink: 0, marginTop: 2, fontFamily: "monospace",
                      }}>{letter}</span>
                      <span style={{ fontSize: 13.5, color: muted, lineHeight: 1.6 }}>{reason}</span>
                    </div>
                  ))}
                </div>
              )}

              <button onClick={() => setShowStudyMode(s => !s)} style={{
                background: showStudyMode ? "#1e1b4b" : "transparent",
                border: "1.5px solid #4338ca", borderRadius: 9,
                color: showStudyMode ? "#a5b4fc" : "#818cf8",
                padding: "7px 14px", cursor: "pointer", fontSize: 12.5, fontWeight: 700,
                fontFamily: "inherit", marginBottom: 14, transition: "all 0.18s",
              }}>
                📚 {showStudyMode ? "Hide" : "Show"} Ideology Breakdown
              </button>

              {showStudyMode && (
                <div style={{
                  background: dark ? "#111827" : "#f5f3ff", border: "1.5px solid #4338ca",
                  borderRadius: 13, padding: "16px 20px", marginBottom: 16,
                  animation: "fadeSlideIn 0.3s ease",
                }}>
                  <div style={{ fontWeight: 700, fontSize: 11.5, color: "#818cf8", marginBottom: 10, letterSpacing: 1, textTransform: "uppercase" }}>
                    Ideologies in This Question
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
                    {set.isms.map(ism => <IsmTag key={ism} label={ism} />)}
                  </div>
                  <div style={{ fontSize: 13.5, color: dark ? "#c4b5fd" : "#4338ca", lineHeight: 1.65 }}>
                    AP Euro examiners test whether you can identify how <strong>{set.isms[0]}</strong> influenced authors, policies, and events.
                    Ask yourself: who benefits from this ideology? Who would oppose it? Why does it emerge when it does?
                  </div>
                </div>
              )}

              <button onClick={handleNext} style={{
                background: `linear-gradient(135deg, ${eraColor.accent}, #7c3aed)`,
                color: "#fff", border: "none", borderRadius: 12,
                padding: "13px 32px", fontSize: 15.5, fontWeight: 700,
                cursor: "pointer", fontFamily: "inherit",
                boxShadow: `0 6px 24px ${eraColor.accent}40`,
              }}>
                {idx + 1 < allQuestions.length ? "Next Question →" : "View Results →"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
