# AP Euro Stimulus Engine 🏛️

A study app for AP European History MCQ practice — with primary sources, art analysis, Ism tagging, and sourcing tooltips.

## Quick Start

### Prerequisites
- [Node.js](https://nodejs.org/) (version 18 or higher)

### Setup

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev

# 3. Open your browser to:
# http://localhost:5173
```

### Build for production
```bash
npm run build
npm run preview
```

## Features
- 📜 Split-pane layout — stimulus on left, questions on right
- 🖼️ Image stimulus with zoom (e.g. Death of Marat)
- 🔍 Source POV tooltip — author's social class, affiliation, bias
- #️⃣ Ism tagging — Mercantilism, Realpolitik, Fascism, etc.
- 🚨 Distractor analysis — why each wrong answer is wrong
- 📚 Study Mode — ideology breakdown after each question
- ⏱️ 75-second countdown timer
- 🌙 Dark/Light mode toggle
- 📊 Results dashboard with ideology performance breakdown

## Adding Questions
Edit `src/questions.js` to add more question sets. Follow the existing format:
- `era`: 1–4
- `stimulus.type`: `"text"` or `"image"`
- `isms`: array of ideology tags
- `questions`: array with `options`, `answer`, `explanation`, `distractors`
